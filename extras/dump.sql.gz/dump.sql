-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: db:3306
-- Generation Time: Feb 19, 2025 at 07:29 PM
-- Server version: 10.11.10-MariaDB-ubu2204-log
-- PHP Version: 8.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `pin_id` int(11) NOT NULL,
  `begin_at` datetime NOT NULL,
  `end_at` datetime DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `pin_id`, `begin_at`, `end_at`, `title`, `user_id`) VALUES
(12, 23, '2025-02-21 18:20:00', '2025-02-26 18:20:00', 'ccc', 4);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `color`) VALUES
(1, 'Test Kategorie', '#99ccff'),
(2, 'neue Kategorie', '#0097A7'),
(3, 'neue Kategorie', '#0097A7'),
(4, 'neue Kategorie', '#0097A7'),
(5, 'neue Kategorie', '#0097A7'),
(6, 'neue Kategorie', '#0097A7'),
(7, 'neue Kategorie', '#0097A7'),
(9, 'test', '#d1c1e4'),
(10, 'hdhdh', '#6fd34a'),
(11, 'ooo', '#3594d0');

-- --------------------------------------------------------

--
-- Table structure for table `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20240229000000', '2025-02-19 08:41:03', 137),
('DoctrineMigrations\\Version20240301000000', '2025-02-19 12:46:58', 69),
('DoctrineMigrations\\Version20250205180616', '2025-02-05 19:06:27', 664),
('DoctrineMigrations\\Version20250216155410', '2025-02-16 16:54:37', 49),
('DoctrineMigrations\\Version20250217192047', '2025-02-17 20:21:29', 67),
('DoctrineMigrations\\Version20250218115310', '2025-02-18 12:53:40', 17),
('DoctrineMigrations\\Version20250218194146', '2025-02-18 20:41:57', 111),
('DoctrineMigrations\\Version20250219072352', '2025-02-19 08:24:00', 49);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `pin_id` int(11) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `pin_id`, `file_path`) VALUES
(1, 3, 'fileadmin/user_uploads/hampter-1.webp');

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE `note` (
  `id` int(11) NOT NULL,
  `pin_id` int(11) NOT NULL,
  `content` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`id`, `pin_id`, `content`) VALUES
(1, 4, 'Hallo, dies ist ein Test. \nIch hoffe es funktioniert.');

-- --------------------------------------------------------

--
-- Table structure for table `pin`
--

CREATE TABLE `pin` (
  `id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `pos_x` int(11) NOT NULL,
  `pos_y` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pin`
--

INSERT INTO `pin` (`id`, `type_id`, `category_id`, `title`, `pos_x`, `pos_y`, `width`, `height`) VALUES
(1, 3, 1, 'Test To Do', 300, 300, 300, 300),
(2, 4, 1, 'TERMIIIN', 300, 300, 300, 300),
(3, 2, 1, 'Hampter Image', 300, 300, 300, 300),
(4, 1, 9, 'Notiz mehrzeilig', 25, 339, 300, 300),
(13, 2, 9, 'hier', 1132, 111, 288, 265),
(23, 3, 11, 'ccc', 47, 79, 200, 200);

-- --------------------------------------------------------

--
-- Table structure for table `pin_type`
--

CREATE TABLE `pin_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pin_type`
--

INSERT INTO `pin_type` (`id`, `name`) VALUES
(1, 'Notiz'),
(2, 'Bild'),
(3, 'To-Do'),
(4, 'Termin');

-- --------------------------------------------------------

--
-- Table structure for table `to_do_entry`
--

CREATE TABLE `to_do_entry` (
  `id` int(11) NOT NULL,
  `pin_id` int(11) NOT NULL,
  `row` int(11) NOT NULL,
  `content` longtext DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `checked` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `to_do_entry`
--

INSERT INTO `to_do_entry` (`id`, `pin_id`, `row`, `content`, `datetime`, `checked`) VALUES
(1, 1, 1, 'Test Aufgabe', '2025-02-19 09:03:44', 0),
(9, 13, 0, '1', NULL, 0),
(10, 13, 0, '2', NULL, 1),
(11, 13, 0, '3', '2025-02-27 17:25:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `auth_token` varchar(255) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `username`, `password`, `auth_token`, `verified`) VALUES
(4, 'zwielicht@test.com', 'zwielicht', '$argon2i$v=19$m=65536,t=4,p=1$YUtZWEVZUDJwRGIwREx3MQ$C8m6VuhfkI0iH2xnE/bFFE6eq4KRU5dRwS523rD74L4', NULL, 1),
(5, 'fake@mail.su', 'SteveJobs', '$argon2i$v=19$m=65536,t=4,p=1$dVhpLnFIOEIuTTkxZ1RqTw$wizEB8Hj6K4FMpYsLqaNzQChJlMc50/Ab1lHUkO5lBY', NULL, 1),
(6, 'testp@test.com', 'Peter', '$argon2i$v=19$m=65536,t=4,p=1$T2ZsMnRnZU9TQnVsbC4yUA$ATfP+mA7fX5YNp+8YGtMOm7/tv8jCbFP9bwW6TFHlmE', NULL, 1),
(7, 'ofentoast@toaster.com', 'Ofenbrot', '$argon2i$v=19$m=65536,t=4,p=1$WEM1TnpWMExBdFpkR3NLLw$s3MFFUy/zasdTRoiSwmT9WtCaZmhgBcs9mroMXVbSb4', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_to_category`
--

CREATE TABLE `user_to_category` (
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_to_category`
--

INSERT INTO `user_to_category` (`category_id`, `user_id`) VALUES
(9, 4),
(10, 4),
(11, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_FE38F8446C3B254C` (`pin_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_C53D045F6C3B254C` (`pin_id`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_CFBDFA146C3B254C` (`pin_id`);

--
-- Indexes for table `pin`
--
ALTER TABLE `pin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B5852DF3C54C8C93` (`type_id`),
  ADD KEY `IDX_B5852DF312469DE2` (`category_id`);

--
-- Indexes for table `pin_type`
--
ALTER TABLE `pin_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `to_do_entry`
--
ALTER TABLE `to_do_entry`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_91FF03C56C3B254C` (`pin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_to_category`
--
ALTER TABLE `user_to_category`
  ADD PRIMARY KEY (`category_id`,`user_id`),
  ADD KEY `IDX_620E4EFA12469DE2` (`category_id`),
  ADD KEY `IDX_620E4EFAA76ED395` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pin`
--
ALTER TABLE `pin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `pin_type`
--
ALTER TABLE `pin_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `to_do_entry`
--
ALTER TABLE `to_do_entry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `FK_FE38F844B6EC9F87` FOREIGN KEY (`pin_id`) REFERENCES `pin` (`id`);

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `FK_C53D045F6C3B254C` FOREIGN KEY (`pin_id`) REFERENCES `pin` (`id`);

--
-- Constraints for table `note`
--
ALTER TABLE `note`
  ADD CONSTRAINT `FK_CFBDFA146C3B254C` FOREIGN KEY (`pin_id`) REFERENCES `pin` (`id`);

--
-- Constraints for table `pin`
--
ALTER TABLE `pin`
  ADD CONSTRAINT `FK_B5852DF312469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_B5852DF3C54C8C93` FOREIGN KEY (`type_id`) REFERENCES `pin_type` (`id`);

--
-- Constraints for table `to_do_entry`
--
ALTER TABLE `to_do_entry`
  ADD CONSTRAINT `FK_91FF03C56C3B254C` FOREIGN KEY (`pin_id`) REFERENCES `pin` (`id`);

--
-- Constraints for table `user_to_category`
--
ALTER TABLE `user_to_category`
  ADD CONSTRAINT `FK_620E4EFA12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_620E4EFAA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
